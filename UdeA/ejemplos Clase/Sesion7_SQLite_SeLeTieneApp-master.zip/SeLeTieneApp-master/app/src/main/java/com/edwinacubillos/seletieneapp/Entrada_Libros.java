package com.edwinacubillos.seletieneapp;

/**
 * Created by Edwin on 3/04/2017.
 */

public class Entrada_Libros {

    String libro, autor, descripcion;

    public Entrada_Libros(String libro, String autor, String descripcion) {
        this.libro = libro;
        this.autor = autor;
        this.descripcion = descripcion;
    }

    public String getLibro() {
        return libro;
    }

    public void setLibro(String libro) {
        this.libro = libro;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
