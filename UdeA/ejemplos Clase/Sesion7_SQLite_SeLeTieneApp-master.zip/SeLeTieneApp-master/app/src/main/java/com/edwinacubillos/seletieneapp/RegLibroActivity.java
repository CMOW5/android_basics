package com.edwinacubillos.seletieneapp;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegLibroActivity extends AppCompatActivity {

    SQLiteHelper sqLiteHelper;
    SQLiteDatabase dbSeLeTieneApp;
    ContentValues dataBD;

    EditText eLibro, eAutor, eDescrip;
    Button bGuardar;

    String libro, autor, descrip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reg_libro);

        sqLiteHelper = new SQLiteHelper(this, "dbSeLeTieneApp",null,1);
        dbSeLeTieneApp = sqLiteHelper.getWritableDatabase();

        eLibro = (EditText) findViewById(R.id.eNombreLibre);
        eAutor = (EditText) findViewById(R.id.eAutorLibro);
        eDescrip = (EditText) findViewById(R.id.eDescripLibro);
        bGuardar = (Button) findViewById(R.id.bGuardar);
    }

    public void onClick(View v) {
        int id = v.getId();

        dataBD = new ContentValues();
        libro = eLibro.getText().toString();
        autor = eAutor.getText().toString();
        descrip = eDescrip.getText().toString();
        switch (id){
            case R.id.bGuardar:
                //Opcion1
                dataBD.put("libro",libro);
                dataBD.put("autor",autor);
                dataBD.put("descripcion",descrip);
                dbSeLeTieneApp.insert("libros",null,dataBD);

                //opcion2
               // dbSeLeTieneApp.execSQL("INSERT INTO libros VALUES (null, '"+libro+"', '"+autor+"', '"+descrip+"')");

                Toast.makeText(getApplicationContext(),"Libro Guardado",Toast.LENGTH_SHORT).show();
                break;

            case R.id.bBuscar:
                break;

            case R.id.bActualizar:
                //Metodo 1
                dataBD.put("autor",autor);
                dataBD.put("descripcion",descrip);
                dbSeLeTieneApp.update("libros",dataBD,"libro='"+libro+"'",null);

                //Metodo 2
                dbSeLeTieneApp.execSQL("UPDATE libros SET autor='"+autor+"'" +
                        ",descripcion='"+descrip+"' WHERE libro = '"+libro+"'");

                Toast.makeText(getApplicationContext(),"Libro Actualizado",Toast.LENGTH_SHORT).show();
                break;

            case R.id.bEliminar:

                dbSeLeTieneApp.delete("libros","libro='"+libro+"'",null);
                Toast.makeText(getApplicationContext(),"Libro Eliminado",Toast.LENGTH_SHORT).show();
                break;
        }
    }
}
