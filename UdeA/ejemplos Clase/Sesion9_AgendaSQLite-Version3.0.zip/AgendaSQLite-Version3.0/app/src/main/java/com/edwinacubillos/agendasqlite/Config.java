package com.edwinacubillos.agendasqlite;

/**
 * Created by Edwin on 20/04/2017.
 */

public class Config {
    public static final String URL_ADD="http://192.168.137.1/agenda/create_contact.php";
    public static final String URL_UPDATE="http://192.168.137.1/agenda/update_contact.php";
    public static final String URL_DELETE="http://192.168.137.1/agenda/delete_contact.php?nombre=";
    public static final String URL_GET_CONTACT="http://192.168.137.1/agenda/get_contact_details.php?nombre=";
}
