package com.edwinacubillos.seletieneapp;

/**
 * Created by Edwin on 19/04/2017.
 */

public class Config {

    public static final String URL_ADD = "http://192.168.137.1/seletieneapp/create_book.php";
    public static final String URL_GET_ALL = "http://192.168.137.1/seletieneapp/get_all_books.php";
    public static final String URL_DELETE = "http://192.168.137.1/seletieneapp/delete_book.php?libro=";
    public static final String URL_UPDATE = "http://192.168.137.1/seletieneapp/update_book.php";

}
