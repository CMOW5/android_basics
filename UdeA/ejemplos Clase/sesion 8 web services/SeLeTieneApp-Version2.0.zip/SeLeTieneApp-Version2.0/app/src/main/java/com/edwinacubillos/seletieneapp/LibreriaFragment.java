package com.edwinacubillos.seletieneapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class LibreriaFragment extends Fragment {

    ListView list;
    Entrada_Libros item;
    ArrayList<Entrada_Libros> lista;
    private String JSON_STRING;

    public LibreriaFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_libreria, container, false);

        list = (ListView) view.findViewById(R.id.list);
        lista = new ArrayList<Entrada_Libros>();

        getJSON();

        return view;
    }

    public void getJSON() {
        class getJSON extends AsyncTask<Void,Void,String>{

            ProgressDialog loading;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(getContext(),"Fetching Data","Wait...",false,false);
            }

            @Override
            protected String doInBackground(Void... params) {
                RequestHandler rh = new RequestHandler();
                String s = rh.sendGetRequest(Config.URL_GET_ALL);
                return s;
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                JSON_STRING = s;
                showBook();
            }
        }
        getJSON gj = new getJSON();
        gj.execute();
    }

    private void showBook() {
        JSONObject jsonObject = null;

        try {
            jsonObject = new JSONObject(JSON_STRING);
            JSONArray result = jsonObject.getJSONArray("result");

            for (int i=0; i <result.length(); i++){
                JSONObject jo = result.getJSONObject(i);
                String id = jo.getString("id");
                String libro = jo.getString("libro");
                String autor = jo.getString(("autor"));
                String descripcion = jo.getString("descripcion");

                item = new Entrada_Libros(libro, autor, descripcion);
                lista.add(item);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
        Adapter adapter = new Adapter(getContext(), lista);
        list.setAdapter(adapter);
    }


    class Adapter extends ArrayAdapter<Entrada_Libros>{

        public Adapter(Context context, ArrayList<Entrada_Libros> libros) {
            super(context, R.layout.list_item, libros);
        }

        public View getView(int position,View convertView,ViewGroup parent) {

            Entrada_Libros libros = getItem(position);

            LayoutInflater inflater = LayoutInflater.from(getContext());
            View item = inflater.inflate(R.layout.list_item,null);

            TextView libro = (TextView) item.findViewById(R.id.tLibro);
            libro.setText(libros.getLibro());

            TextView autor = (TextView) item.findViewById(R.id.tAutor);
            autor.setText(libros.getAutor());

            TextView descrip = (TextView) item.findViewById(R.id.tDescrip);
            descrip.setText(libros.getDescripcion());

            return item;







        }
    }

}
