package com.edwinacubillos.seletieneapp;

import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.HashMap;

public class RegLibroActivity extends AppCompatActivity {

    ContentValues dataBD;

    EditText eLibro, eAutor, eDescrip;

    String libro, autor, descrip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reg_libro);

        eLibro = (EditText) findViewById(R.id.eNombreLibre);
        eAutor = (EditText) findViewById(R.id.eAutorLibro);
        eDescrip = (EditText) findViewById(R.id.eDescripLibro);
    }

    public void onClick(View v) {
        int id = v.getId();

        dataBD = new ContentValues();
        libro = eLibro.getText().toString();
        autor = eAutor.getText().toString();
        descrip = eDescrip.getText().toString();
        switch (id){
            case R.id.bGuardar:
               addBook();
                Toast.makeText(getApplicationContext(),"Libro Guardado",Toast.LENGTH_SHORT).show();
                break;
            case R.id.bBuscar:
                break;
            case R.id.bActualizar:
                updateBook();
                Toast.makeText(getApplicationContext(),"Libro Actualizado",Toast.LENGTH_SHORT).show();
                break;
            case R.id.bEliminar:
                deleteBook();
                Toast.makeText(getApplicationContext(),"Libro Eliminado",Toast.LENGTH_SHORT).show();
                break;
        }
        Intent intent = new Intent (RegLibroActivity.this, MainActivity.class);
        startActivity(intent);
    }

    private void updateBook() {
        class UpdateBook extends AsyncTask<Void, Void, String> {

            ProgressDialog loading;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(RegLibroActivity.this,"Updating...","Wait...",false,false);

            }
            @Override
            protected String doInBackground(Void... v) {
                HashMap<String,String> params = new HashMap<>();
                params.put("libro",libro);
                params.put("autor",autor);
                params.put("descripcion",descrip);

                RequestHandler rh = new RequestHandler();
                String res = rh.sendPostRequest(Config.URL_UPDATE,params);
                return res;
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                Toast.makeText(RegLibroActivity.this, s, Toast.LENGTH_SHORT).show();
            }
        }

        UpdateBook ue = new UpdateBook();
        ue.execute();
    }

    private void deleteBook() {
        class DeleteBook extends AsyncTask<Void, Void, String> {

            ProgressDialog loading;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(RegLibroActivity.this,"Delete...","Wait...",false,false);
            }

            @Override
            protected String doInBackground(Void... params) {
                RequestHandler rh = new RequestHandler();
                String s = rh.sendGetRequestParam(Config.URL_DELETE,libro);
                Log.d("libro a eliminar", libro);
                return s;
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                Toast.makeText(RegLibroActivity.this, s, Toast.LENGTH_SHORT).show();
            }
        }

        DeleteBook de = new DeleteBook();
        de.execute();
    }

    private void addBook() {
        class AddBook extends AsyncTask<Void, Void, String> {

            ProgressDialog loading;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(RegLibroActivity.this,"Adding...","Wait...",false,false);
            }

            @Override
            protected String doInBackground(Void... v) {
                HashMap<String,String> params = new HashMap<>();
                params.put("libro",libro);
                params.put("autor",autor);
                params.put("descripcion",descrip);

                RequestHandler rh = new RequestHandler();
                String res = rh.sendPostRequest(Config.URL_ADD,params);
                return res;
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                Toast.makeText(RegLibroActivity.this, s, Toast.LENGTH_SHORT).show();
            }
        }

        AddBook ae = new AddBook();
        ae.execute();
    }
}
